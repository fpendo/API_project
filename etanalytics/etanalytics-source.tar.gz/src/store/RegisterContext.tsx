import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react'
import { generateHistoricalRegisters, generateHistoricalWorkflows } from './historicalData'

// Interface for an uploaded register
export interface UploadedRegister {
  id: string
  issuerId: string
  issuerName: string
  fileName: string
  uploadDate: string
  registerDate: string  // The date the share register was issued (from the issuer)
  totalHolders: number
  status: 'pending' | 'in_progress' | 'analyzed' | 'delivered'
  discoveredPct?: number
  etfs: Array<{
    isin: string
    name: string
    totalShares: number
  }>
  nominees: Array<{
    name: string
    accountNumber?: string
    holdings: Record<string, number>
    totalShares: number
  }>
}

interface RegisterContextType {
  uploadedRegisters: UploadedRegister[]
  addRegister: (register: UploadedRegister) => void
  removeRegister: (id: string) => void
  clearAllRegisters: () => void
  getRegister: (id: string) => UploadedRegister | undefined
  getRegistersForIssuer: (issuerId: string) => UploadedRegister[]
  updateRegisterStatus: (id: string, status: UploadedRegister['status'], discoveredPct?: number) => void
  initializeWithHistoricalData: () => void
}

const RegisterContext = createContext<RegisterContextType | undefined>(undefined)

// LocalStorage keys
const STORAGE_KEY = 'etanalytics_registers'
const WORKFLOWS_STORAGE_KEY = 'etanalytics_workflows'

export const RegisterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [uploadedRegisters, setUploadedRegisters] = useState<UploadedRegister[]>(() => {
    // Load from localStorage on init
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (parsed.length > 0) {
          return parsed
        }
      }
    } catch (e) {
      console.error('Failed to load registers from localStorage:', e)
    }
    // Initialize with historical data if nothing saved
    const historical = generateHistoricalRegisters()
    localStorage.setItem(STORAGE_KEY, JSON.stringify(historical))
    
    // Also generate and save workflows
    const workflows = generateHistoricalWorkflows(historical)
    localStorage.setItem(WORKFLOWS_STORAGE_KEY, JSON.stringify(workflows))
    
    return historical
  })

  // Save to localStorage whenever registers change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(uploadedRegisters))
    } catch (e) {
      console.error('Failed to save registers to localStorage:', e)
    }
  }, [uploadedRegisters])

  const addRegister = (register: UploadedRegister) => {
    setUploadedRegisters(prev => {
      // Check if already exists (by id)
      const exists = prev.some(r => r.id === register.id)
      if (exists) {
        return prev.map(r => r.id === register.id ? register : r)
      }
      return [...prev, register]
    })
  }

  const removeRegister = (id: string) => {
    setUploadedRegisters(prev => prev.filter(r => r.id !== id))
  }
  
  const clearAllRegisters = () => {
    setUploadedRegisters([])
  }

  const getRegister = (id: string) => {
    return uploadedRegisters.find(r => r.id === id)
  }
  
  const getRegistersForIssuer = (issuerId: string) => {
    return uploadedRegisters.filter(r => r.issuerId === issuerId)
  }
  
  const updateRegisterStatus = (id: string, status: UploadedRegister['status'], discoveredPct?: number) => {
    setUploadedRegisters(prev => prev.map(r => 
      r.id === id ? { ...r, status, discoveredPct: discoveredPct ?? r.discoveredPct } : r
    ))
  }
  
  const initializeWithHistoricalData = () => {
    const historical = generateHistoricalRegisters()
    setUploadedRegisters(historical)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(historical))
    
    // Also regenerate workflows
    const workflows = generateHistoricalWorkflows(historical)
    localStorage.setItem(WORKFLOWS_STORAGE_KEY, JSON.stringify(workflows))
  }

  return (
    <RegisterContext.Provider value={{ 
      uploadedRegisters, 
      addRegister, 
      removeRegister, 
      clearAllRegisters, 
      getRegister,
      getRegistersForIssuer,
      updateRegisterStatus,
      initializeWithHistoricalData
    }}>
      {children}
    </RegisterContext.Provider>
  )
}

export const useRegisters = () => {
  const context = useContext(RegisterContext)
  if (!context) {
    throw new Error('useRegisters must be used within a RegisterProvider')
  }
  return context
}

// Helper function to parse CSV and create a register
export const parseCSVToRegister = (
  csvContent: string,
  issuerId: string,
  issuerName: string,
  registerDate?: string  // Optional: the date the share register was issued
): UploadedRegister => {
  const lines = csvContent.trim().split('\n')
  const headers = lines[0].split(',')
  
  // First two columns are nominee name and account number, rest are ISINs
  const hasAccountNumber = headers[1]?.toLowerCase().includes('account') || headers[1]?.toLowerCase().includes('number')
  const isinStartIndex = hasAccountNumber ? 2 : 1
  const isins = headers.slice(isinStartIndex).map(h => h.trim())
  
  // Parse each nominee row
  const nominees: Array<{ name: string; accountNumber?: string; holdings: Record<string, number>; totalShares: number }> = []
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',')
    const nomineeName = values[0]?.trim()
    const accountNumber = hasAccountNumber ? values[1]?.trim() : undefined
    const holdings: Record<string, number> = {}
    let totalShares = 0
    
    for (let j = isinStartIndex; j < values.length; j++) {
      const isin = isins[j - isinStartIndex]?.trim()
      const shares = parseInt(values[j]) || 0
      if (isin && shares > 0) {
        holdings[isin] = shares
        totalShares += shares
      }
    }
    
    if (nomineeName && Object.keys(holdings).length > 0) {
      nominees.push({ name: nomineeName, accountNumber, holdings, totalShares })
    }
  }
  
  // Build ETF list with total shares
  const etfTotals: Record<string, number> = {}
  nominees.forEach(nom => {
    Object.entries(nom.holdings).forEach(([isin, shares]) => {
      etfTotals[isin] = (etfTotals[isin] || 0) + shares
    })
  })
  
  // Comprehensive ISIN to name mapping
  const isinToName: Record<string, string> = {
    // iShares
    'IE00B4L5Y983': 'iShares Core MSCI World UCITS ETF',
    'IE00B5BMR087': 'iShares Core S&P 500 UCITS ETF',
    'IE00B3F81R35': 'iShares Core S&P 500 UCITS ETF (Dist)',
    'IE00BKM4GZ66': 'iShares NASDAQ 100 UCITS ETF',
    'IE00B4L5YC18': 'iShares Core Euro STOXX 50 UCITS ETF',
    'IE00B52MJY50': 'iShares Core MSCI EM IMI UCITS ETF',
    'IE00B3RBWM25': 'iShares Core MSCI Emerging Markets UCITS ETF',
    'IE00B52SF786': 'iShares Core MSCI Japan IMI UCITS ETF',
    'IE00BF4RFE31': 'iShares Automation & Robotics UCITS ETF',
    'IE00B53SZB19': 'iShares Global Clean Energy UCITS ETF',
    // Vanguard
    'IE00BK5BQT80': 'Vanguard FTSE All-World UCITS ETF (Acc)',
    'IE00B3VVMM84': 'Vanguard FTSE All-World UCITS ETF (Dist)',
    'IE00B3XXRP09': 'Vanguard S&P 500 UCITS ETF (Acc)',
    'IE00BFMXXD54': 'Vanguard S&P 500 UCITS ETF (Dist)',
    'IE00BK5BQV03': 'Vanguard FTSE Developed World UCITS ETF',
    'IE00BK5BR733': 'Vanguard FTSE Emerging Markets UCITS ETF',
    'IE00B95PGT31': 'Vanguard FTSE Developed Europe UCITS ETF',
    // Amundi
    'LU1681043599': 'Amundi MSCI World UCITS ETF',
    'LU1681048804': 'Amundi S&P 500 UCITS ETF',
    'LU1135865084': 'Amundi MSCI Emerging Markets UCITS ETF',
    'LU1681038672': 'Amundi Euro STOXX 50 UCITS ETF',
  }
  
  const etfs = Object.entries(etfTotals).map(([isin, totalShares]) => ({
    isin,
    name: isinToName[isin] || `ETF ${isin.slice(-4)}`,
    totalShares
  }))
  
  const now = new Date()
  const uploadDate = now.toISOString().split('T')[0]
  const monthStr = now.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })
  
  return {
    id: `reg-${issuerId}-${Date.now()}`,
    issuerId,
    issuerName,
    fileName: `${issuerName} Share Register ${monthStr}.csv`,
    uploadDate,
    registerDate: registerDate || uploadDate,  // Default to upload date if not provided
    totalHolders: nominees.length,
    status: 'pending',
    etfs,
    nominees
  }
}

