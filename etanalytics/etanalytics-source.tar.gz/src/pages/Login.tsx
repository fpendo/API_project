import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Eye, ArrowRight, Building2, BarChart3 } from 'lucide-react'

const Login = () => {
  const navigate = useNavigate()
  const [loginType, setLoginType] = useState<'issuer' | 'analyst'>('issuer')
  const [selectedIssuer, setSelectedIssuer] = useState('')

  const issuers = [
    { id: 'amundi', name: 'Amundi' },
    { id: 'vanguard', name: 'Vanguard' },
    { id: 'invesco', name: 'Invesco' },
    { id: 'blackrock', name: 'BlackRock (iShares)' },
    { id: 'state-street', name: 'State Street (SPDR)' },
  ]

  const handleLogin = () => {
    if (loginType === 'analyst') {
      navigate('/analysis')
    } else if (selectedIssuer) {
      navigate('/issuer')
    }
  }

  return (
    <div className="min-h-screen bg-dark-950 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 mesh-gradient" />
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-500/10 rounded-full blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md"
      >
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 justify-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
            <Eye className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-semibold text-white">ET Analytics</span>
        </Link>

        {/* Login Card */}
        <div className="card-glass rounded-2xl p-8">
          <h1 className="text-2xl font-bold text-white text-center mb-2">Welcome Back</h1>
          <p className="text-gray-400 text-center mb-8">Select your portal to continue</p>

          {/* Portal Toggle */}
          <div className="flex bg-dark-800 rounded-xl p-1 mb-8">
            <button
              onClick={() => setLoginType('issuer')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all ${
                loginType === 'issuer'
                  ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Building2 className="w-4 h-4" />
              Issuer Portal
            </button>
            <button
              onClick={() => setLoginType('analyst')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all ${
                loginType === 'analyst'
                  ? 'bg-gradient-to-r from-accent-500 to-accent-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              Analyst Portal
            </button>
          </div>

          {loginType === 'issuer' ? (
            <>
              {/* Issuer Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Select Your Organization
                </label>
                <select
                  value={selectedIssuer}
                  onChange={(e) => setSelectedIssuer(e.target.value)}
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500 transition-colors"
                >
                  <option value="">Choose an issuer...</option>
                  {issuers.map((issuer) => (
                    <option key={issuer.id} value={issuer.id}>
                      {issuer.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="you@company.com"
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500 transition-colors"
                />
              </div>

              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary-500 transition-colors"
                />
              </div>
            </>
          ) : (
            <>
              {/* Analyst Login */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Analyst Email
                </label>
                <input
                  type="email"
                  placeholder="analyst@etanalytics.com"
                  defaultValue="analyst@etanalytics.com"
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent-500 transition-colors"
                />
              </div>

              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  defaultValue="password"
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent-500 transition-colors"
                />
              </div>
            </>
          )}

          <button
            onClick={handleLogin}
            disabled={loginType === 'issuer' && !selectedIssuer}
            className={`w-full py-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-all ${
              loginType === 'issuer'
                ? 'bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-400 hover:to-primary-500 disabled:opacity-50 disabled:cursor-not-allowed'
                : 'bg-gradient-to-r from-accent-500 to-accent-600 hover:from-accent-400 hover:to-accent-500'
            } text-white`}
          >
            Sign In <ArrowRight className="w-4 h-4" />
          </button>

          <p className="text-center text-gray-500 text-sm mt-6">
            Demo mode: Select any issuer or use analyst portal
          </p>
        </div>

        {/* Back to Home */}
        <p className="text-center text-gray-500 mt-6">
          <Link to="/" className="hover:text-white transition-colors">
            ← Back to Home
          </Link>
        </p>
      </motion.div>
    </div>
  )
}

export default Login

