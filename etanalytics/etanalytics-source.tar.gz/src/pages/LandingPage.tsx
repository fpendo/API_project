import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Eye,
  TrendingUp,
  Shield,
  Zap,
  BarChart3,
  Globe,
  Building2,
  Users,
  ChevronRight,
  CheckCircle,
  ArrowRight,
  Play,
  Layers,
  Target,
  LineChart,
  Database,
  Lock,
  Clock,
  Menu,
  X
} from 'lucide-react'

const LandingPage = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  }

  const staggerChildren = {
    animate: { transition: { staggerChildren: 0.1 } }
  }

  return (
    <div className="min-h-screen bg-dark-950 text-white overflow-hidden">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-dark-950/90 backdrop-blur-xl border-b border-white/5' : ''
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
                <Eye className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-semibold">Exchange Traded Analytics</span>
            </Link>
            
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-400 hover:text-white transition-colors">Features</a>
              <a href="#how-it-works" className="text-gray-400 hover:text-white transition-colors">How It Works</a>
              <a href="#market" className="text-gray-400 hover:text-white transition-colors">Market</a>
              <a href="#pricing" className="text-gray-400 hover:text-white transition-colors">Pricing</a>
              <Link to="/login" className="text-gray-400 hover:text-white transition-colors">Login</Link>
              <Link to="/login" className="btn-primary flex items-center gap-2">
                Get Started <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <button 
              className="md:hidden text-gray-400"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden bg-dark-900 border-b border-white/5 px-6 py-4"
          >
            <div className="flex flex-col gap-4">
              <a href="#features" className="text-gray-400 hover:text-white">Features</a>
              <a href="#how-it-works" className="text-gray-400 hover:text-white">How It Works</a>
              <a href="#market" className="text-gray-400 hover:text-white">Market</a>
              <a href="#pricing" className="text-gray-400 hover:text-white">Pricing</a>
              <Link to="/login" className="btn-primary text-center">Get Started</Link>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        {/* Background Effects */}
        <div className="absolute inset-0 mesh-gradient" />
        <div className="absolute inset-0 grid-bg" />
        
        {/* Floating Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/20 rounded-full blur-[100px] animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-500/20 rounded-full blur-[100px] animate-pulse-slow" style={{ animationDelay: '2s' }} />
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/20 text-primary-400 text-sm mb-8">
              <Zap className="w-4 h-4" />
              <span>Powered by Irish Companies Act Section 1062</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight">
              Finally See Who
              <br />
              <span className="gradient-text">Owns Your ETFs</span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-12">
              The only ownership analytics platform built for ETF issuers. 
              Turn your share register into distribution intelligence.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <Link 
                to="/login" 
                className="btn-primary text-lg px-8 py-4 flex items-center gap-2"
              >
                Start Free Trial <ArrowRight className="w-5 h-5" />
              </Link>
              <button className="btn-secondary text-lg px-8 py-4 flex items-center gap-2">
                <Play className="w-5 h-5" /> Watch Demo
              </button>
            </div>

            {/* Stats Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              {[
                { value: '$3.1T', label: 'European ETF AUM' },
                { value: '78%', label: 'Irish Domiciled' },
                { value: '70+', label: 'Target Issuers' },
                { value: '15%', label: 'Annual Growth' }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold gradient-text mb-1">{stat.value}</div>
                  <div className="text-gray-500 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500">
          <span className="text-sm">Scroll to explore</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <ChevronRight className="w-5 h-5 rotate-90" />
          </motion.div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="grid lg:grid-cols-2 gap-16 items-center"
          >
            <motion.div variants={fadeInUp}>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                The <span className="text-red-400">$3 Trillion</span> Blind Spot
              </h2>
              <p className="text-xl text-gray-400 mb-8">
                ETF issuers like BlackRock, Vanguard, and Amundi cannot see who actually owns their products. 
                Exchange trading creates layers of custodians and nominees that obscure true ownership.
              </p>
              
              <div className="space-y-4">
                {[
                  'Shares held in nominee accounts',
                  'Multi-layer custodian chains',
                  'No visibility into distribution partners',
                  'Unable to identify key relationships'
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-gray-300">
                    <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div variants={fadeInUp} className="relative">
              {/* Custody Chain Visualization */}
              <div className="card-glass rounded-2xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-3xl" />
                
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-dark-800 rounded-xl">
                    <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-purple-400" />
                    </div>
                    <div>
                      <div className="font-medium">ETF Issuer</div>
                      <div className="text-sm text-gray-500">Only sees top layer</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <div className="w-px h-8 bg-gradient-to-b from-purple-500 to-gray-600" />
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-dark-800 rounded-xl opacity-70">
                    <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Database className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <div className="font-medium">Euroclear / Clearstream</div>
                      <div className="text-sm text-gray-500">Central Securities Depository</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <div className="w-px h-8 bg-gradient-to-b from-blue-500 to-gray-600" />
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-dark-800 rounded-xl opacity-50">
                    <div className="w-12 h-12 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                      <Lock className="w-6 h-6 text-yellow-400" />
                    </div>
                    <div>
                      <div className="font-medium">Custodian Nominees</div>
                      <div className="text-sm text-gray-500">State Street, BNY Mellon...</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <div className="w-px h-8 bg-gradient-to-b from-yellow-500 to-gray-600" />
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-dark-800 rounded-xl opacity-30">
                    <div className="w-12 h-12 rounded-lg bg-gray-500/20 flex items-center justify-center">
                      <Users className="w-6 h-6 text-gray-400" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-400">??? Unknown ???</div>
                      <div className="text-sm text-gray-600">Who owns the shares?</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Solution Section */}
      <section id="features" className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 mesh-gradient opacity-50" />
        
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="text-center mb-16"
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent-500/10 border border-accent-500/20 text-accent-400 text-sm mb-6">
              <Shield className="w-4 h-4" />
              <span>Legal Framework: Irish Companies Act 2014</span>
            </motion.div>
            
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              We've <span className="gradient-text">Cracked the Code</span>
            </motion.h2>
            
            <motion.p variants={fadeInUp} className="text-xl text-gray-400 max-w-3xl mx-auto">
              Using Section 1062 of the Irish Companies Act, we can legally compel custodians 
              to disclose ownership — giving you complete visibility into your investor base.
            </motion.p>
          </motion.div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Layers,
                title: 'Peel Back the Layers',
                description: 'Systematically unwrap custody chains to reveal the true investment decision-makers behind nominee accounts.',
                color: 'primary'
              },
              {
                icon: Target,
                title: 'Identify Key Relationships',
                description: 'Discover which wealth managers, private banks, and platforms are driving flows to your ETFs.',
                color: 'accent'
              },
              {
                icon: LineChart,
                title: 'Track Changes Daily',
                description: 'Monitor ownership changes in real-time for known entities. See net new assets flow instantly.',
                color: 'primary'
              },
              {
                icon: BarChart3,
                title: 'Quarterly Deep Analysis',
                description: 'Comprehensive ownership reports with full disclosure process. Maximum monthly frequency available.',
                color: 'accent'
              },
              {
                icon: Globe,
                title: '78% Market Coverage',
                description: 'Ireland dominates European ETF domicile. One jurisdiction covers the vast majority of the market.',
                color: 'primary'
              },
              {
                icon: Database,
                title: 'Entity Intelligence',
                description: 'Our growing database of 5,000+ entities enables instant matching of dedicated nominee accounts.',
                color: 'accent'
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card-glass card-hover rounded-2xl p-8"
              >
                <div className={`w-14 h-14 rounded-xl bg-${feature.color}-500/20 flex items-center justify-center mb-6`}>
                  <feature.icon className={`w-7 h-7 text-${feature.color}-400`} />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="relative py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              How It <span className="gradient-text">Works</span>
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-gray-400 max-w-2xl mx-auto">
              From share register to actionable intelligence in four simple steps.
            </motion.p>
          </motion.div>

          <div className="relative">
            {/* Connection Line */}
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary-500/50 to-transparent" />
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  step: '01',
                  title: 'Upload Register',
                  description: 'Upload your share register or connect via API. Sign authorization for disclosure requests.',
                  icon: Database
                },
                {
                  step: '02',
                  title: 'Auto-Match Entities',
                  description: 'Our system instantly identifies known entities — wealth managers, platforms, dedicated nominees.',
                  icon: Target
                },
                {
                  step: '03',
                  title: 'Issue Disclosures',
                  description: 'Section 1062 notices sent to custodians. Responses processed and ownership attributed.',
                  icon: Shield
                },
                {
                  step: '04',
                  title: 'Deliver Insights',
                  description: 'Comprehensive ownership reports delivered. Track changes, identify relationships, drive strategy.',
                  icon: BarChart3
                }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15 }}
                  className="relative"
                >
                  <div className="card-glass rounded-2xl p-8 h-full">
                    <div className="text-6xl font-bold text-white/5 absolute top-4 right-4">
                      {item.step}
                    </div>
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center mb-6 relative z-10">
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                    <p className="text-gray-400">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Market Opportunity */}
      <section id="market" className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 mesh-gradient opacity-30" />
        
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="grid lg:grid-cols-2 gap-16 items-center"
          >
            <motion.div variants={fadeInUp}>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/20 text-primary-400 text-sm mb-6">
                <TrendingUp className="w-4 h-4" />
                <span>Market Opportunity</span>
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                The European ETF Market is <span className="gradient-text">Exploding</span>
              </h2>
              
              <p className="text-xl text-gray-400 mb-8">
                With $3.11 trillion in AUM and 15% annual growth, the market is projected 
                to reach $4.5 trillion by 2030. Ireland's dominance as the ETF domicile 
                of choice makes our solution uniquely positioned.
              </p>

              <div className="space-y-6">
                {[
                  { label: 'European ETF AUM (2025)', value: '$3.11T', growth: '+32.6% YTD' },
                  { label: 'Irish Domicile Market Share', value: '78%', growth: '~$2.4T' },
                  { label: 'Projected 2030 AUM', value: '$4.5T', growth: '+45%' },
                  { label: 'Active Issuers', value: '70+', growth: 'Addressable' }
                ].map((stat, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-dark-800/50 rounded-xl">
                    <span className="text-gray-400">{stat.label}</span>
                    <div className="text-right">
                      <span className="text-xl font-bold">{stat.value}</span>
                      <span className="text-sm text-accent-400 ml-2">{stat.growth}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div 
              variants={fadeInUp}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="relative"
            >
              {/* Visual Chart Mockup */}
              <div className="card-glass rounded-2xl p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-semibold">European ETF Growth</h3>
                  <span className="text-sm text-gray-500">2020 - 2030</span>
                </div>
                
                <div className="relative h-64 mt-4">
                  {/* Y-axis labels */}
                  <div className="absolute left-0 top-0 bottom-8 w-12 flex flex-col justify-between text-xs text-gray-500">
                    <span>$4.5T</span>
                    <span>$3.0T</span>
                    <span>$1.5T</span>
                    <span>$0</span>
                  </div>
                  
                  {/* Chart container */}
                  <div className="absolute bottom-0 left-16 right-0 top-0 pl-2">
                    <div className="relative h-full pb-8">
                      {/* Grid lines */}
                      <div className="absolute inset-0 flex flex-col justify-between">
                        <div className="h-px bg-white/5"></div>
                        <div className="h-px bg-white/5"></div>
                        <div className="h-px bg-white/5"></div>
                        <div className="h-px bg-white/10"></div>
                      </div>
                      
                      {/* Bars */}
                      <div className="relative h-full flex items-end justify-between gap-1.5">
                        {[
                          { year: '20', height: 24, value: '$1.1T' },
                          { year: '21', height: 33, value: '$1.5T' },
                          { year: '22', height: 29, value: '$1.3T' },
                          { year: '23', height: 40, value: '$1.8T' },
                          { year: '24', height: 50, value: '$2.3T' },
                          { year: '25', height: 69, value: '$3.1T' },
                          { year: '26', height: 76, value: '$3.4T', projected: true },
                          { year: '27', height: 83, value: '$3.7T', projected: true },
                          { year: '28', height: 90, value: '$4.0T', projected: true },
                          { year: '30', height: 100, value: '$4.5T', projected: true }
                        ].map((bar, i) => (
                          <div key={i} className="flex-1 flex flex-col items-center h-full justify-end pb-6 group relative min-w-0">
                            {/* Tooltip */}
                            <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-dark-900 border border-white/10 px-2 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                              {bar.value}
                            </div>
                            
                            {/* Bar */}
                            <motion.div
                              initial={{ scaleY: 0, opacity: 0 }}
                              whileInView={{ scaleY: 1, opacity: 1 }}
                              viewport={{ once: true, margin: "-100px" }}
                              transition={{ 
                                delay: i * 0.08, 
                                duration: 0.6,
                                ease: [0.4, 0, 0.2, 1]
                              }}
                              style={{ 
                                height: `${bar.height}%`,
                                transformOrigin: 'bottom'
                              }}
                              className={`w-full rounded-t-lg relative overflow-hidden min-h-[4px] ${
                                bar.projected 
                                  ? 'bg-gradient-to-t from-primary-500/40 to-accent-500/40 border-2 border-dashed border-primary-400/40' 
                                  : 'bg-gradient-to-t from-primary-600 to-accent-500'
                              }`}
                            >
                              {/* Shimmer effect */}
                              {!bar.projected && (
                                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                              )}
                            </motion.div>
                            
                            {/* Year label */}
                            <span className={`text-xs mt-2 absolute bottom-0 ${bar.projected ? 'text-gray-600' : 'text-gray-500'}`}>
                              '{bar.year}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6 mt-6 pt-6 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-gradient-to-r from-primary-600 to-accent-500" />
                    <span className="text-sm text-gray-400">Actual</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded border border-dashed border-primary-400/30 bg-primary-500/30" />
                    <span className="text-sm text-gray-400">Projected</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Target Customers */}
      <section className="relative py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              Built for the <span className="gradient-text">World's Largest</span> ETF Issuers
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-gray-400 max-w-2xl mx-auto">
              From global giants to specialist boutiques, we serve issuers who want 
              complete visibility into their distribution.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              'BlackRock', 'Vanguard', 'State Street', 'Amundi', 
              'Invesco', 'DWS', 'UBS', 'HSBC',
              'WisdomTree', 'JP Morgan', 'Franklin Templeton', 'VanEck'
            ].map((name, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="card-glass rounded-xl p-6 flex items-center justify-center hover:border-primary-500/30 transition-colors cursor-pointer"
              >
                <span className="text-gray-400 font-medium">{name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 mesh-gradient opacity-30" />
        
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerChildren}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              Simple, <span className="gradient-text">Transparent</span> Pricing
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-gray-400 max-w-2xl mx-auto">
              Choose the plan that fits your needs. All plans include full platform access and support.
            </motion.p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: 'Starter',
                price: '£80,000',
                period: '/year',
                description: 'For emerging issuers',
                features: [
                  'Up to 10 ETF products',
                  'Quarterly full analysis',
                  'Daily tracking (known entities)',
                  'Entity database access',
                  'Standard support'
                ],
                cta: 'Get Started',
                highlighted: false
              },
              {
                name: 'Professional',
                price: '£150,000',
                period: '/year',
                description: 'For established issuers',
                features: [
                  'Up to 50 ETF products',
                  'Monthly full analysis',
                  'Daily tracking (known entities)',
                  'Custom entity tagging',
                  'API access',
                  'Priority support'
                ],
                cta: 'Get Started',
                highlighted: true
              },
              {
                name: 'Enterprise',
                price: 'Custom',
                period: '',
                description: 'For global leaders',
                features: [
                  'Unlimited ETF products',
                  'On-demand analysis',
                  'Real-time tracking',
                  'Custom integrations',
                  'Dedicated account team',
                  'SLA guarantee'
                ],
                cta: 'Contact Sales',
                highlighted: false
              }
            ].map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-2xl p-8 relative ${
                  plan.highlighted 
                    ? 'bg-gradient-to-b from-primary-500/20 to-dark-800 border-2 border-primary-500/50' 
                    : 'card-glass'
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary-500 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <p className="text-gray-500 text-sm mb-6">{plan.description}</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-500">{plan.period}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-gray-300">
                      <CheckCircle className="w-5 h-5 text-accent-400 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 rounded-lg font-medium transition-all ${
                  plan.highlighted 
                    ? 'bg-primary-500 hover:bg-primary-400 text-white' 
                    : 'border border-white/20 hover:border-primary-400 hover:text-primary-400'
                }`}>
                  {plan.cta}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to See Your <span className="gradient-text">True Ownership</span>?
            </h2>
            <p className="text-xl text-gray-400 mb-8">
              Join the leading ETF issuers who have unlocked complete visibility 
              into their distribution.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link 
                to="/login" 
                className="btn-primary text-lg px-8 py-4 flex items-center gap-2"
              >
                Start Your Free Trial <ArrowRight className="w-5 h-5" />
              </Link>
              <a href="mailto:contact@etanalytics.com" className="btn-secondary text-lg px-8 py-4">
                Contact Sales
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold">ET Analytics</span>
              </div>
              <p className="text-gray-500">
                The only ownership analytics platform built for ETF issuers.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-500">
                <li><a href="#features" className="hover:text-white">Features</a></li>
                <li><a href="#pricing" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">API Documentation</a></li>
                <li><a href="#" className="hover:text-white">Integrations</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-500">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Press</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-500">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">GDPR</a></li>
                <li><a href="#" className="hover:text-white">Security</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">
              © 2026 Exchange Traded Analytics. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-gray-500">
              <span className="text-sm">Powered by Irish Companies Act Section 1062</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage

