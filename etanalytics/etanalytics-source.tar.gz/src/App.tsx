import { Routes, Route } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import IssuerDashboard from './pages/IssuerDashboard'
import AnalysisDashboard from './pages/AnalysisDashboard'
import Login from './pages/Login'
import { RegisterProvider } from './store/RegisterContext'
import { ActivityProvider } from './store/ActivityContext'
import { ETFDatabaseProvider } from './store/ETFDatabaseContext'

function App() {
  return (
    <ActivityProvider>
      <ETFDatabaseProvider>
        <RegisterProvider>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/issuer/*" element={<IssuerDashboard />} />
            <Route path="/analysis/*" element={<AnalysisDashboard />} />
          </Routes>
        </RegisterProvider>
      </ETFDatabaseProvider>
    </ActivityProvider>
  )
}

export default App

